---
trigger: always_on
---

-Always use sematic HTML5 elements for better accessibity and SEO
-Maintain consistent spacing using an 8px grid system throughout the design
-all animations should respect preferred-reduced-motion for accessibility
-use CSS variables for all colors enable easy theme switching.




